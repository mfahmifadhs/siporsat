<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard Pengelolaan AADB</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item active">
                        <a href="<?php echo e(url('super-user/aadb/usulan/pengadaan/kendaraan')); ?>" class="btn btn-primary">Usulan <br> Pengadaan</a>
                        <a href="<?php echo e(url('super-user/aadb/usulan/servis/kendaraan')); ?>" class="btn btn-primary">Usulan <br> Servis</a>
                        <a href="<?php echo e(url('super-user/aadb/usulan/perpanjangan-stnk/kendaraan')); ?>" class="btn btn-primary">Usulan <br> Perpanjangan STNK</a>
                        <a href="<?php echo e(url('super-user/aadb/usulan/voucher-bbm/kendaraan')); ?>" class="btn btn-primary">Usulan <br> Voucher BBM</a>
                    </li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">

    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_super_user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_super_user/apk_aadb/index.blade.php ENDPATH**/ ?>