<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Daftar Barang</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('admin-user/oldat/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active"><a href="<?php echo e(url('admin-user/oldat/barang/data/semua')); ?>">Daftar Barang</a></li>
                    <li class="breadcrumb-item active">Barang</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 form-group">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
                </div>
                <?php elseif($message = Session::get('failed')): ?>
                <div class="alert alert-danger">
                    <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
            </div>
            <div class="col-md-3">
                <div class="card card-primary card-outline">
                    <div class="card-body box-profile text-capitalize">
                        <div class="text-center">
                            <?php if($barang->foto_barang == null): ?>
                            <img src="<?php echo e(asset('dist_admin/img/1224838.png')); ?>" class="img-thumbnail mt-2" style="width: 100%;">
                            <?php else: ?>
                            <img src="<?php echo e(asset('gambar/barang_bmn/'. $barang->foto_barang)); ?>" class="img-thumbnail mt-2" style="width: 100%;">
                            <?php endif; ?>
                        </div>
                        <h3 class="profile-username text-center"><?php echo e($barang->kategori_barang); ?></h3>
                        <p class="text-muted text-center"><?php echo e($barang->spesifikasi_barang); ?></p>
                    </div>
                </div>
            </div>
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header p-2">
                        <ul class="nav nav-pills">
                            <li class="nav-item"><a class="nav-link active" href="#informasi-barang" data-toggle="tab">Informasi Barang</a></li>
                            <li class="nav-item"><a class="nav-link" href="#riwayat-barang" data-toggle="tab">Riwayat</a></li>
                        </ul>
                    </div>
                    <div class="card-body">
                        <div class="tab-content">
                            <div class="active tab-pane" id="informasi-barang">
                                <form action="<?php echo e(url('admin-user/oldat/barang/proses-ubah/'. $barang->id_barang)); ?>" method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-md-12">
                                            <label>Upload Foto Barang</label>
                                            <p>
                                                <?php if($barang->foto_barang == null): ?>
                                                <img id="preview-image-before-upload" src="<?php echo e(asset('dist_admin/img/1224838.png')); ?>" class="img-responsive img-thumbnail mt-2" style="width: 10%;">
                                                <?php else: ?>
                                                <img id="preview-image-before-upload" src="<?php echo e(asset('gambar/barang_bmn/'. $barang->foto_barang)); ?>" class="img-responsive img-thumbnail mt-2" style="width: 10%;">
                                                <?php endif; ?>
                                            </p>
                                            <p>
                                            <div class="btn btn-default btn-file">
                                                <i class="fas fa-paperclip"></i> Upload Foto
                                                <input type="hidden" class="form-control image" name="foto_lama" value="<?php echo e($barang->foto_barang); ?>">
                                                <input type="file" class="form-control image" name="foto_barang" accept="image/jpeg , image/jpg, image/png" value="<?php echo e($barang->foto_barang); ?>">
                                            </div><br>
                                            <span class="help-block" style="font-size: 12px;">Format foto jpg/jpeg/png dan max 4 MB</span>
                                            </p>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Pengguna Barang :</label>
                                            <select name="id_pegawai" class="form-control">
                                                <option value="">-- Pilih Pegawai --</option>
                                                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataPegawai): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dataPegawai->id_pegawai); ?>" <?php if ($barang->pegawai_id == $dataPegawai->id_pegawai) echo "selected"; ?>>
                                                    <?php echo e($dataPegawai->nama_pegawai); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Kategori Barang :</label>
                                            <select name="id_kategori_barang" class="form-control">
                                                <option value="">-- Pilih Level --</option>
                                                <?php $__currentLoopData = $kategoriBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dataKategoriBarang->id_kategori_barang); ?>" <?php if ($barang->kategori_barang_id == $dataKategoriBarang->id_kategori_barang) echo "selected"; ?>>
                                                    <?php echo e($dataKategoriBarang->kategori_barang); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Kode Barang : </label>
                                            <input type="text" name="kode_barang" class="form-control" value="<?php echo e($barang->kode_barang); ?>">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>NUP : </label>
                                            <input type="text" name="nup_barang" class="form-control" value="<?php echo e($barang->nup_barang); ?>">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Jumlah : </label>
                                            <input type="text" name="jumlah_barang" class="form-control" value="<?php echo e($barang->jumlah_barang); ?>">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Satuan : </label>
                                            <input type="text" name="satuan_barang" class="form-control" value="<?php echo e($barang->satuan_barang); ?>">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label>Tahun Perolehan : </label>
                                            <input type="text" name="tahun_perolehan" class="form-control" value="<?php echo e($barang->tahun_perolehan); ?>">
                                        </div>
                                        <div class="col-md-6 form-group">
                                            <label for="level">Kondisi Barang :</label>
                                            <select name="id_kondisi_barang" class="form-control">
                                                <option value="">-- Pilih Kondisi Barang --</option>
                                                <?php $__currentLoopData = $kondisiBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKondisiBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($dataKondisiBarang->id_kondisi_barang); ?>" <?php if ($barang->kondisi_barang_id == $dataKondisiBarang->id_kondisi_barang) echo "selected"; ?>>
                                                    <?php echo e($dataKondisiBarang->kondisi_barang); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                        <div class="col-md-12 form-group">
                                            <label>Spesifikasi : </label>
                                            <textarea type="text" name="spesifikasi_barang" class="form-control" rows="5"><?php echo e($barang->spesifikasi_barang); ?></textarea>
                                        </div>
                                        <div class="col-md-12 form-group">
                                            <button type="button" class="btn btn-default">Close</button>
                                            <button type="submit" class="btn btn-primary" onclick="return confirm('Ubah Informasi Barang ?')">Submit</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                            <div class="tab-pane" id="riwayat-barang">
                                <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $riwayatPengguna): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="timeline timeline-inverse">
                                    <div class="time-label">
                                        <span class="bg-danger">
                                            <?php echo e(\Carbon\Carbon::parse($riwayatPengguna->tanggal_pengguna)->isoFormat('DD MMMM Y')); ?>

                                        </span>
                                    </div>
                                    <div>
                                        <i class="fas fa-user bg-primary"></i>

                                        <div class="timeline-item">
                                            <span class="time"><i class="far fa-clock"></i> 12:05</span>

                                            <h3 class="timeline-header text-capitalize">
                                                <a href="#"><?php echo e($riwayatPengguna->nama_pegawai); ?></a> <br> <?php echo e($riwayatPengguna->jabatan.' '.$riwayatPengguna->keterangan_pegawai); ?></h3>

                                            <div class="timeline-body">
                                                <?php echo e($riwayatPengguna->keperluan_penggunaan); ?>

                                            </div>
                                            <div class="timeline-footer">
                                                <span class="badge badge-primary">Kondisi Barang <?php echo e($riwayatPengguna->kondisi_barang); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $('.image').change(function() {
        let reader = new FileReader();

        reader.onload = (e) => {
            $('#preview-image-before-upload').attr('src', e.target.result);
        }
        reader.readAsDataURL(this.files[0]);
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_admin_user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_admin_user/apk_oldat/detail_barang.blade.php ENDPATH**/ ?>