@extends('v_admin_user.layout.app')

@section('content')

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Dashboard Pengelolaan BMN OLDAT</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item active">Dashboard OLDAT</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-6 form-group">
                <div class="card text-center">
                    <div class="card-header">
                        <h4 class="card-title">GRAFIK</h4>
                    </div>
                    <div class="card-body">
                        ...
                    </div>
                </div>
            </div>
            <div class="col-md-6 form-group">
                <div class="card text-center">
                    <div class="card-header">
                        <h4 class="card-title">GRAFIK</h4>
                    </div>
                    <div class="card-body">
                        ...
                    </div>
                </div>
            </div>
        </div>

        <center>
            <div class="col-md-5 form-group">
                <div class="card text-center">
                    <div class="card-header">
                        <h4 class="card-title">GRAFIK</h4>
                    </div>
                    <div class="card-body">
                        ...
                    </div>
                </div>
            </div>
        </center>
    </div>
</section>

@endsection
