<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Level Pengguna</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="<?php echo e(url('super-admin/oldat/dashboard')); ?>">Dashboard</a></li>
                    <li class="breadcrumb-item active">Level Pengguna</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="col-md-12 form-group">
            <?php if($message = Session::get('success')): ?>
            <div class="alert alert-success">
                <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
            </div>
            <?php elseif($message = Session::get('failed')): ?>
            <div class="alert alert-danger">
                <p style="color:white;margin: auto;"><?php echo e($message); ?></p>
            </div>
            <?php endif; ?>
        </div>
        <div class="card">
            <div class="card-body">
                <table id="table-level" class="table table-bordered text-capitalize">
                    <thead>
                        <tr>
                            <th>No</th>
                            <th>Level</th>
                        </tr>
                    </thead>
                    <?php $no = 1; ?>
                    <tbody>
                        <?php $__currentLoopData = $level; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($no++); ?></td>
                            <td><?php echo e($row->level); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-level").DataTable({
            "responsive": true,
            "lengthChange": true,
            "autoWidth": false,
            "buttons": ["excel", "pdf", "print"]
        }).buttons().container().appendTo('#table-workunit_wrapper .col-md-6:eq(0)');
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_super_admin.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_super_admin/daftar_level.blade.php ENDPATH**/ ?>