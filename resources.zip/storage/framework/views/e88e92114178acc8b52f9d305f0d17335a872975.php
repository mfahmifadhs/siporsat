<!DOCTYPE html>
<html>

<head>
    <title>Membuat Laporan PDF Dengan DOMPDF Laravel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>

<body>
    <style type="text/css">
        table tr td,
        table tr th {
            font-size: 9pt;
        }
    </style>
    <center>
        <h5>Membuat Laporan PDF Dengan DOMPDF Laravel</h4>
            <h6><a target="_blank" href="https://www.malasngoding.com/membuat-laporan-…n-dompdf-laravel/">www.malasngoding.com</a>
        </h5>
    </center>

    <table class='table table-bordered'>
        <thead>
            <tr>
                <th>No</th>
                <th>Kode Barang</th>
                <th>NUP</th>
                <th>Nama Barang</th>
                <th>Merk</th>
                <th>Jumlah</th>
                <th>Satuan</th>
                <th>Tahun Perolehan</th>
                <th>Kondisi</th>
                <th>Pengguna</th>
            </tr>
        </thead>
        <?php $no = 1; ?>
        <tbody>
            <?php $__currentLoopData = $barang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($row->kode_barang); ?></td>
                <td><?php echo e($row->nup_barang); ?></td>
                <td><?php echo e($row->kategori_barang); ?></td>
                <td><?php echo e($row->spesifikasi_barang); ?></td>
                <td><?php echo e($row->jumlah_barang); ?></td>
                <td><?php echo e($row->satuan_barang); ?></td>
                <td><?php echo e($row->tahun_perolehan); ?></td>
                <td><?php echo e($row->kondisi_barang); ?></td>
                <td><?php echo e($row->nama_pegawai); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

</body>

</html>
<?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_super_user/apk_oldat/pdf_barang.blade.php ENDPATH**/ ?>