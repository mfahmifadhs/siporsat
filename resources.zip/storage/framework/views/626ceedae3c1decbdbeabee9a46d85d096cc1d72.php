<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Rekapitulasi</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#"> Dashboard OLDAT</a></li>
                    <li class="breadcrumb-item active">Rekapitulasi Pengelolaan Olah Data (BMN)</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row form-group">
            <div class="col-md-4 form-group">
                <select id="dataRekap" class="form-control">
                    <option value="0">Rekap Berdasarkan Tahun Perolehan</option>
                    <option value="1">Rekap Berdasarkan Kategori Barang</option>
                    <option value="2">Rekap Berdasarkan Tim Kerja</option>
                    <option value="3">Rekap Berdasarkan Unit Kerja </option>
                </select>
            </div>
            <div class="col-md-2 form-group">
                <a id="btnPilihRekap" class="btn btn-primary">Pilih</a>
            </div>
        </div>
        <div class="row form-group" id="rekap-default">
            <div class="col-md-12">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h4 class="card-title">Rekapitulasi Barang</h4>
                    </div>
                    <div class="card-body" id="table-rekap">
                        <table id="table-1" class="table table-bordered table-responsive">
                            <thead>
                                <tr class="bg-light">
                                    <th style="width:10%;">Tahun</th>
                                    <th style="width:40%;">Tim Kerja</th>
                                    <?php $__currentLoopData = $kategoriBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th><?php echo e($dataKategoriBarang->kategori_barang); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $rekapTahunPerolehan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tahun => $dataUnitKerja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <tr>
                                    <td rowspan="<?php echo e($timKerja->count()+1); ?>" class="text-centerl po"><?php echo e($tahun); ?></td>
                                </tr>
                                <?php $__currentLoopData = $rekapTahunPerolehan[$tahun]['biro umum']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiker => $dataKategoriBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tiker); ?></td>
                                    <?php $__currentLoopData = $dataKategoriBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $totalBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($totalBarang); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <?php echo e($tahunPerolehan->links("pagination::bootstrap-4")); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-1").DataTable({
            "responsive": true,
            "lengthChange": true,
            "autoWidth": false,
            "buttons": ["pdf", "excel"]
        }).buttons().container().appendTo('#table-1_wrapper .col-md-6:eq(0)');
    });

    $('#btnPilihRekap').click(function() {
        $("#table-rekap").empty();
        let no = 2;
        let i;
        let data = $('#dataRekap').val();
        console.log(data);
        if (data == 1) {
            $("#table-rekap").append(
                `<table id="table-1" class="table table-bordered">
                    <thead>
                        <tr>
                            <th style="width: 50%;">Nama Barang</th>
                            <th>Jumlah Barang</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $rekapTotalBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataTotalBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($dataTotalBarang->kategori_barang); ?></td>
                            <td><?php echo e($dataTotalBarang->totalbarang); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>`

            );
        } else if (data == 2) {
            $("#table-rekap").append(
                `<table class="table table-bordered table-responsive">
                            <tr>
                                <th style="width:40%;">Tim Kerja</th>
                                <?php $__currentLoopData = $kategoriBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($dataKategoriBarang->kategori_barang); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                                <?php $__currentLoopData = $rekapTimKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiker => $timKerja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($tiker); ?></td>
                                    <?php $__currentLoopData = $timKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $totalBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($totalBarang); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>`
            );
        } else if (data == 3) {
            $("#table-rekap").append(
                `<table class="table table-bordered table-responsive">
                            <tr>
                                <th style="width:80%;">Unit Kerja</th>
                                <?php $__currentLoopData = $kategoriBarang; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataKategoriBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <th><?php echo e($dataKategoriBarang->kategori_barang); ?></th>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tr>
                                <?php $__currentLoopData = $rekapUnitKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unker => $unitKerja): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($unker); ?></td>
                                    <?php $__currentLoopData = $unitKerja; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kategori => $totalBarang): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td><?php echo e($totalBarang); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>`
            );
        } else if (data == 0) {
            location.reload();
        }
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_super_user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_super_user/apk_oldat/daftar_rekap.blade.php ENDPATH**/ ?>