<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Buat Usulan Perbaikan</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#"> Dashboard</a></li>
                    <li class="breadcrumb-item"><a href="<?php echo e(url('super-user/oldat/pengajuan/daftar/semua-pengajuan')); ?>"> Daftar Pengajuan</a></li>
                    <li class="breadcrumb-item active">Buat Usulan Perbaikan</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if($message = Session::get('success')): ?>
                <div class="alert alert-success">
                    <p style="margin: auto;"><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
                <?php if($message = Session::get('failed')): ?>
                <div class="alert alert-danger">
                    <p style="margin: auto;"><?php echo e($message); ?></p>
                </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_super_user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_super_user/apk_oldat/usulan_perbaikan.blade.php ENDPATH**/ ?>