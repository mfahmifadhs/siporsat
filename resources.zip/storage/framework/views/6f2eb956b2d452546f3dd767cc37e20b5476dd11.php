<?php $__env->startSection('content'); ?>

<div class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">
                <h1 class="m-0">Rekapitulasi</h1>
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#"> Dashboard OLDAT</a></li>
                    <li class="breadcrumb-item active">Rekapitulasi Pengelolaan Olah Data (BMN)</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<section class="content">
    <div class="container-fluid">
        <div class="row form-group">
            <div class="col-md-4 form-group">
                <select id="dataRekap" class="form-control">
                    <option value="0">Rekap Berdasarkan Unit Kerja</option>
                    <option value="1">Rekap Berdasarkan Tahun Kendaraan</option>
                </select>
            </div>
            <div class="col-md-2 form-group">
                <a id="btnPilihRekap" class="btn btn-primary">Pilih</a>
            </div>
        </div>
        <div class="row form-group" id="rekap-default">
            <div class="col-md-12">
                <div class="card card-outline card-primary">
                    <div class="card-header">
                        <h4 class="card-title">Rekapitulasi Barang</h4>
                    </div>
                    <div class="card-body">
                        <table id="table-rekap" class="table table-bordered">
                            <thead>
                                <tr>
                                    <th class="text-center">No</th>
                                    <th class="text-center">Unit Kerja</th>
                                    <?php $__currentLoopData = $jenisKendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dataJenken): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <th class="text-center"><?php echo e($dataJenken->jenis_kendaraan); ?></th>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                            </thead>

                            <?php $no = 1; ?>
                            <tbody>
                                <?php $__currentLoopData = $rekapUnker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unitKerja => $jenisKendaraan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($no++); ?></td>
                                    <td><?php echo e($unitKerja); ?></td>
                                    <?php $__currentLoopData = $jenisKendaraan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenKen => $total): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <td class="text-center"> <?php echo e($total); ?></td>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>

                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<?php $__env->startSection('js'); ?>
<script>
    $(function() {
        $("#table-rekap").DataTable({
            "responsive": true,
            "lengthChange": true,
            "autoWidth": false,
            buttons: [
                {
                    extend: 'pdf',
                    text: ' PDF',
                    className: 'fas fa-file btn btn-primary mr-2 rounded',
                    title: 'rekapitulasi_aadb'
                },
                {
                    extend: 'excel',
                    text: ' Excel',
                    className: 'fas fa-file btn btn-primary mr-2 rounded',
                    title: 'rekapitulasi_aadb'
                }
            ]
        }).buttons().container().appendTo('#table-rekap_wrapper .col-md-6:eq(0)');
    });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('v_super_user.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\mfahm\Documents\GitHub\e-office\resources\views/v_super_user/apk_aadb/daftar_rekap.blade.php ENDPATH**/ ?>